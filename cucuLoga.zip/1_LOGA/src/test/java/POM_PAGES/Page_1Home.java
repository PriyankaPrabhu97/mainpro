package POM_PAGES;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import BASE_CLASSes.Wait;

public class Page_1Home {
	
	WebDriver dr;
	Wait wt;
	
	public Page_1Home(WebDriver dr) 
	{
		this.dr = dr;
		wt = new Wait(dr);	
	}
	
	public void women()
	{		
		WebElement wo  = dr.findElement(By.xpath("//a[@title='Women']"));
		Actions MS = new Actions(dr);
		MS.moveToElement(wo).build().perform();
		
		String WT = dr.getTitle();
		System.out.println(WT);
	}

}
