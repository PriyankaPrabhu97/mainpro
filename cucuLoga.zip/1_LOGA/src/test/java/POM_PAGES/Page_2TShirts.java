package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSes.Wait;

public class Page_2TShirts {
	
	WebDriver dr;
	Wait wt;
	
	public Page_2TShirts(WebDriver dr) 
	{
		this.dr = dr;
		wt = new Wait(dr);	
	}
	
	public void TShirts()
	{
		By TS = By.xpath("//a[@title='T-shirts']");
		WebElement wt_TS = wt.elementToBeClickable(TS, 20);
		wt_TS.click();
		
		String TsT = dr.getTitle();
		System.out.println(TsT);
	}

}
