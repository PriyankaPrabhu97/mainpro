package STEP_DEFINITION;

import org.openqa.selenium.WebDriver;

import BASE_CLASSes.Browsers;
import BASE_CLASSes.Wait;
import POM_PAGES.Page_1Home;
import POM_PAGES.Page_2TShirts;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_1 {
	
	WebDriver dr;
	Browsers Br;
	Wait wt;
	Page_1Home P1;
	Page_2TShirts P2;
	
	String URL = "http://automationpractice.com/index.php";
	
	@Given("^Browser is launched & products are displayed$")
	public void browser_is_launched_products_are_displayed() throws Throwable {		
		System.out.println("browser_is_launched_products_are_displayed");
		Br = new Browsers(dr);
		dr = Br.Launch("Chrome", URL);    
	}

	@When("^Click on add to cart$")
	public void click_on_add_to_cart() throws Throwable {
		P1 = new Page_1Home(dr);
		P1.women();
		P2.TShirts();
	}

	@Then("^Succefully add products to cart$")
	public void succefully_add_products_to_cart() throws Throwable {		
		System.out.println("succefully_add_products_to_cart");
	    
	}

}
