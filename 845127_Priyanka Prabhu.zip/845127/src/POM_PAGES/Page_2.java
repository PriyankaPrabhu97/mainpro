package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASS.Wait;

public class Page_2 {
	
	WebDriver dr;
	Wait wt;
	public Page_2(WebDriver dr)
	{
		this.dr = dr;
		wt = new Wait(dr);
	}
	
	By dwn_zip =By.partialLinkText("64 bit Windows IE");
	//To click on 64 bit Windows IE & download
	public void download_zip()
	{		
		WebElement wt_dwn_zip=wt.elementToBeClickable(dwn_zip, 20);
		wt_dwn_zip.click();
		
		System.out.println("Click for download");
	}

}
