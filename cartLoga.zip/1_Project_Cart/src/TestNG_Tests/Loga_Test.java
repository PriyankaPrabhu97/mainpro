package TestNG_Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base_Class.Browsers;
import POM_Pages.Page_1;

public class Loga_Test {
	
	WebDriver dr;
	Browsers Br;
	Page_1 P1;
	
	String URL = "http://automationpractice.com/index.php";
	@BeforeClass
	public void launcher()
	{
		Br = new Browsers(dr);
		dr = Br.Launch("Chrome", URL);
	}
	
	@Test
	public void f()
	{
		P1 = new Page_1(dr);
		P1.women();
		P1.item();
		P1.cart();
		P1.checkout();
	}
	
	
}
