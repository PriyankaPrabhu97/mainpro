package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Base_Class.Wait;

public class Page_1 {
	
	WebDriver dr;
	Wait wt;
	public Page_1(WebDriver dr)
	{
		this.dr = dr;
		wt = new Wait(dr);
	}
	
	public void women()
	{		
		WebElement we  = dr.findElement(By.xpath("//a[@title='Women']"));
		Actions MS = new Actions(dr);
		MS.moveToElement(we).build().perform();
		
		By wmn =By.xpath("//a[@title='T-shirts']");
		WebElement wt_wmn=wt.elementToBeClickable(wmn, 20);
		wt_wmn.click();
		
		String WT = dr.getTitle();
		System.out.println(WT);
	}
	
	
	public void item()
	{
		By itm =By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div");
		WebElement wt_itm=wt.elementToBeClickable(itm, 20);
		wt_itm.click();
	}
	
	public void cart()
	{
		By crt =By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[1]/span");
		WebElement wt_crt=wt.elementToBeClickable(crt, 20);
		wt_crt.click();
	}
	
	
	public void checkout()
	{
		By checkout =By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span");
		WebElement wt_checkout=wt.elementToBeClickable(checkout, 20);
		wt_checkout.click();
	}
}
